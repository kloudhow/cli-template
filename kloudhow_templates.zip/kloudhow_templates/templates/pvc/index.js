const path = require('path');

module.exports = {
  description: 'New PVC File',
  prompts: [
    {
      type: 'input',
      name: 'name',
      message: 'input  name'
    }
  ],
  actions: function(data) {
    const pathToContainer = path.join(process.cwd(), 'pvc');
    global.env = {}
    // @TODO: update config
    data.GCP_PROJECT = process.env.GCP_PROJECT
    if(Object.keys(global.env).length > 0){
      data.env = global.env
    }
    data.PVC_ENABLE = process.env.PVC_ENABLE
    if(Object.keys(global.env).length > 0){
      data.env = global.env
    }
    data.PVC_MOUNTPATH = process.env.PVC_MOUNTPATH
    if(Object.keys(global.env).length > 0){
      data.env = global.env
    }
    if(data.PVC_MOUNTPATH && data.PVC_ENABLE ) {
      data.PVC = 1
    }
    const actions = [
      {
        type: 'add',
        path: path.join(pathToContainer, 'uat-{{dashCase name}}-pvc.yml'),
        templateFile: path.join(__dirname, 'pvc.yml.hbs'),
        force: true,
        data: {
          ...data,
          uat: true,
        },
        abortOnFail: true
      },

      {
        type: 'add',
        path: path.join(pathToContainer, 'prod-{{dashCase name}}-pvc.yml'),
        templateFile: path.join(__dirname, 'pvc.yml.hbs'),
        force: true,
        data: {
          ...data,
          prod: true,
        },
        abortOnFail: true
      }
    ];

    return actions;
  }
};
