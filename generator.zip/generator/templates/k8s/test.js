const readline = require('readline');
const fs = require('fs');

const envFile = '.env';
if(fs.existsSync(envFile)){
 let envData = fs.readFileSync(envFile, 'utf8')

    let lines = envData.split(/\r?\n/)
    
    for (let i = 0 ; i<lines.length; i++){
        console.log(lines[i])
        var [key, value] = lines[i].split('=');
        console.log({value, key})
    }
}
// fs.exists('.env', function(exists) {
//     console.log(exists);
//     if (exists) {
//         const readInterface = readline.createInterface({
//             input: fs.createReadStream('.env')
//             // output: process.stdout
//             // console: false
//         });
//         readInterface.on('line', function (line) {
//             var splitstring = line.split('=');
//             var test = splitstring[0];
//
//             console.log(test);
//         });
//
//     }
// });


// console.log(test);