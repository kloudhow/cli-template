const TEMPLATE_PATH = './templates'


const k8s = require(`${TEMPLATE_PATH}/k8s/index.js`)
const config = require(`${TEMPLATE_PATH}/config/index.js`)
const cm = require(`${TEMPLATE_PATH}/cm/index.js`)
const pvc = require(`${TEMPLATE_PATH}/pvc/index.js`)
const pipeline_exec = require(`${TEMPLATE_PATH}/pipeline_exec/index.js`)

module.exports = function (plop) {
  plop.setGenerator('k8s', k8s)
  plop.setGenerator('cm', cm)
  plop.setGenerator('pvc', pvc)
  plop.setGenerator('pipeline_exec', pipeline_exec)
  plop.setGenerator('config', config)
  plop.setGenerator('init', {
    description: 'Init ONE Service',
    prompts: [
      {
        type: 'input',
        name: 'name',
        message: 'Your service name?'
      },
      {
        type: 'list',
        name: 'framework',
        message: 'Select your framework',
        default: 'sails',
        choices: () => [
          'sails',
          'adonis'
        ]
      },
      {
        type: 'list',
        name: 'db',
        message: 'Select your DB engine',
        default: 'none',
        choices: () => [
          'none',
          'psql',
          'mongodb'
        ]
      }
    ],
    actions: [
      {
        type: 'addMany',
        destination: process.cwd(),
        base: __dirname + '/app/{{framework}}',
        globOptions: {
          ignore: [
            '*DS_*'
          ],
          dot: true,
          absolute: true,
        },
        templateFiles: 'app/{{framework}}/**',
      }
    ]
  })
  // add some helpers
  plop.setHelper('ifeq', (a, b, options) => {if (a == b) { return options.fn(this)}})
  plop.setHelper('or', (a, b) => {return a || b})
  plop.setHelper('assign', function (varName, varValue, options) {

    let value = varValue;
    if(typeof varValue === 'object'){
      value = value[0] || value[1];
    }
    if (!options.data.root) {
      options.data.root = {}
    }
    options.data.root[varName] = value
  })
  // plop.setPartial('env', '<h1>{{namespace}}</h1>');
}
