const path = require('path');

module.exports = {
  description: 'New pipeline scripts',
  prompts: [
    {
      type: 'input',
      name: 'name',
      message: 'input  name'
    }
  ],
  actions: function(data) {
    const pathToContainer = path.join(process.cwd(), 'k8s');
    global.env = {}
    // @TODO: update config
    data.GCP_PROJECT = process.env.GCP_PROJECT
    data.GCP_ZONE = process.env.GCP_ZONE
    data.K8S_CLUSTER = process.env.K8S_CLUSTER
    data.CI_COMMIT_SHA = process.env.CI_COMMIT_SHA
    data.CI_COMMIT_TAG = process.env.CI_COMMIT_TAG
    data.BUILD_IMAGE = process.env.BUILD_IMAGE
    data.TAG_IMAGE = process.env.TAG_IMAGE
    data.RELEASE_IMAGE = process.env.RELEASE_IMAGE


    const actions = [
      {
        type: 'add',
        path: path.join(pathToContainer, 'build.sh'),
        templateFile: path.join(__dirname, 'build.sh.hbs'),
        force: true,
        data: {
          ...data,
        },
        abortOnFail: true
      },

      {
        type: 'add',
        path: path.join(pathToContainer, 'active.sh'),
        templateFile: path.join(__dirname, 'active.sh.hbs'),
        force: true,
        data: {
          ...data,
        },
        abortOnFail: true
      },

      {
        type: 'add',
        path: path.join(pathToContainer, 'release-uat.sh'),
        templateFile: path.join(__dirname, 'release-uat.sh.hbs'),
        force: true,
        data: {
          ...data,
          prod: true,
        },
        abortOnFail: true
      },
      {
        type: 'add',
        path: path.join(pathToContainer, 'release.sh'),
        templateFile: path.join(__dirname, 'release.sh.hbs'),
        force: true,
        data: {
          ...data,
        },
        abortOnFail: true
      },
      {
        type: 'add',
        path: path.join(pathToContainer, 'release-hotfix.sh'),
        templateFile: path.join(__dirname, 'release-hotfix.sh.hbs'),
        force: true,
        data: {
          ...data,
        },
        abortOnFail: true
      }
    ];

    return actions;
  }
};
